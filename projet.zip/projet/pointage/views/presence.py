##Impot Presence model
from pointage.models import Presence, PicturePointage, PresenceDay
from pointage.serializers.presence import PresenceDaySerializer
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework import status


class ListPresence(ListAPIView):
    serializer_class = PresenceDaySerializer
    queryset = PresenceDay.objects.all()
    # authentication_classes = (JWTAuthentication,)
    # permission_classes = (IsAuthenticated,)
    # pagination_class = PageNumberPagination


class PresenceControl(APIView):
    def get_object(self, pk):
        try:
            return PresenceDay.objects.get(pk=pk)
        except Presence.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        presence = self.get_object(pk)
        serializer = PresenceSerializer(presence)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        presence = self.get_object(pk)
        serializer = PresenceSerializer(presence, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

    def delete(self, request, pk, format=None):
        presence = self.get_object(pk)
        presence.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



class PresenceCreate(APIView):
    # parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        presence_serializer = PresenceSerializer(data=request.data)
        if presence_serializer.is_valid():
            presence_serializer.save()
            return Response(presence_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(presence_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class Test(APIView):
    def get(self, request, format=None):
        print("AUTH WITH SUCCESS")
        return Response("AUTH WITH SUCCESS")


class CreatePointage(APIView):

    def post(self, request):
        try:
            data = request.data
            user_id = PicturePointage.objects.filter(user=data['user_id'])
            if user_id:
                return Response({'message': 'user already exist'}, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'message': 'user not found'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)