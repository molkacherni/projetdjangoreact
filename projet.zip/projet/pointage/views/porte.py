from pointage.models import Porte, Materiel, PicturePointage
from pointage.serializers.materiel import MaterielDeleteSerializer
from pointage.serializers.porte import PorteSerializer, PorteSerilizerWithTheirDepartements, PorteDeleteSerializer
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from pointage.picture_seriliazer import PicturePointageSerializerName
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.pagination import PageNumberPagination
from django.http import Http404
from rest_framework.response import Response
from rest_framework import status

class ListPorte(ListAPIView):
    serializer_class = PorteSerilizerWithTheirDepartements
    queryset = Porte.objects.filter(is_deleted=False)
    # authentication_classes = (JWTAuthentication,)
    # permission_classes = (IsAuthenticated,)
    # pagination_class = PageNumberPagination

class ListePorteWithTheirUsersAndThirPictures(APIView):
    def get(self, request, format=None):
        porte = Porte.objects.filter(is_deleted=False)
        serializer = PorteSerilizerWithTheirDepartements(porte, many=True)
        portes = serializer.data
        for porte in portes:
            pics = []
            for user in porte['users']:
                pics_user = PicturePointage.objects.filter(user=user['id'])
                serializer = PicturePointageSerializerName(pics_user, many=True)
                for pic in serializer.data:
                    pics.append(pic['pic_name'])
            porte['users_pics'] = pics
        return Response(portes)
    

class PorteControl(APIView):
    def get_object(self, pk):
        try:
            return Porte.objects.get(pk=pk)
        except Porte.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        porte = self.get_object(pk)
        serializer = PorteSerilizerWithTheirDepartements(porte)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        porte = self.get_object(pk)
        serializer = PorteSerializer(porte, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

    def delete(self, request, pk, format=None):
        try:
            porte = self.get_object(pk)
            materiels = Materiel.objects.filter(porte=porte)
            porte_delete_data = { "is_deleted": True }
            materiel_delete_data = { "is_deleted": True }
            for materiel in materiels:
                serializer = MaterielDeleteSerializer(materiel, data=materiel_delete_data)
                if serializer.is_valid():
                    serializer.save()
            serializer = PorteDeleteSerializer(porte, data=porte_delete_data)
            if serializer.is_valid():
                serializer.save()
                return Response(data="Porte deleted successfully", status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(data={"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        


class PorteCreate(APIView):
    # parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        porte_serializer = PorteSerializer(data=request.data)
        if porte_serializer.is_valid():
            porte_serializer.save()
            return Response(porte_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(porte_serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AssignUserToPort(APIView):
    def get_object(self, pk):
        try:
            return Porte.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404

    def post(self, request, pk, format=None):
        try: 
            porte = self.get_object(pk)
            porte.users.add(request.data['user_id'])
            porte.save()
            return Response(data="User added to porte", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)


class AssignManyUsersToPorte(APIView):
    def get_object(self, pk):
        try:
            return Porte.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404
    
    def post(self, request, pk, format=None):
        try:
            porte = self.get_object(pk)
            porte.users.add(*request.data['users'])
            porte.save()
            return Response(data="Users added to porte", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)


class RemoveUserFromPorte(APIView):
    def get_object(self, pk):
        try:
            return Porte.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404
    
    def post(self, request, pk, format=None):
        try:
            porte = self.get_object(pk)
            porte.users.remove(request.data['user_id'])
            porte.save()
            return Response(data="User removed from porte", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)


class ToggleOpenDoor(APIView):
    def get_object(self, pk):
        try:
            return Porte.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404
    
    def post(self, request, pk, format=None):
        try:
            porte = self.get_object(pk)
            porte.is_open = not porte.is_open
            porte.save()
            return Response(data="Door state changed", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)