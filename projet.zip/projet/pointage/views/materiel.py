from pointage.models import Materiel
from pointage.serializers.materiel import MaterielSerializer, MaterialSerializerWithTheirPorte, MaterielDeleteSerializer
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.pagination import PageNumberPagination
from django.http import Http404
from rest_framework_simplejwt.tokens import RefreshToken

from rest_framework.response import Response
from rest_framework import status

class ListMateriel(ListAPIView):
    serializer_class = MaterialSerializerWithTheirPorte
    queryset = Materiel.objects.filter(is_deleted=False)
    # authentication_classes = (JWTAuthentication,)
    # permission_classes = (IsAuthenticated,)
    # pagination_class = PageNumberPagination

class MaterielControl(APIView):
    def get_object(self, pk):
        try:
            return Materiel.objects.get(pk=pk)
        except Materiel.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        materiel = self.get_object(pk)
        serializer = MaterialSerializerWithTheirPorte(materiel)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        materiel = self.get_object(pk)

        serializer = MaterielSerializer(materiel, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

    def delete(self, request, pk, format=None):
        materiel = self.get_object(pk)
        serializer = MaterielDeleteSerializer(materiel, data={"is_deleted": True})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)


class MaterielCreate(APIView):
    # parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        materiel_serializer = MaterielSerializer(data=request.data)
        if materiel_serializer.is_valid():
            materiel_serializer.save()
            return Response(materiel_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(materiel_serializer.errors, status=status.HTTP_400_BAD_REQUEST)