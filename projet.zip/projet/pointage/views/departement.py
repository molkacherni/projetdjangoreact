from pointage.models import Departement, Porte, Materiel
from pointage.serializers.departement import DepartementSerializer, DepartementCreateAndUpdateSerializer, DepartementDeleteSerializer
from pointage.serializers.porte import PorteDeleteSerializer
from pointage.serializers.materiel import MaterielDeleteSerializer
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.pagination import PageNumberPagination
from django.http import Http404
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status



class ListDepartement(ListAPIView):
    serializer_class = DepartementSerializer
    queryset = Departement.objects.filter(is_deleted=False)
    # authentication_classes = (JWTAuthentication,)
    # permission_classes = (IsAuthenticated,)
    # pagination_class = PageNumberPaginations

class DepartementControl(APIView):
    def get_object(self, pk):
        try:
            return Departement.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        departement = self.get_object(pk)
        serializer = DepartementSerializer(departement)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        departement = self.get_object(pk)
        serializer = DepartementCreateAndUpdateSerializer(departement, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

    def delete(self, request, pk, format=None):
        ##delete all porte and materiel of this departement
        try:
            departement = self.get_object(pk)
            portes = Porte.objects.filter(departement=departement)
            materiels = []
            for porte in portes:
                materiels += Materiel.objects.filter(porte=porte)

        

            materiel_delete_data = { "is_deleted": True }
            porte_delete_data = { "is_deleted": True }
            departement_delete_data = { "is_deleted": True }

            for materiel in materiels:
                serializer = MaterielDeleteSerializer(materiel, data=materiel_delete_data)
                if serializer.is_valid():
                    serializer.save()


            for porte in portes:
                serializer = PorteDeleteSerializer(porte, data=porte_delete_data)
                if serializer.is_valid():
                    serializer.save()


            serializer = DepartementDeleteSerializer(departement, data=departement_delete_data)
            if serializer.is_valid():
                serializer.save()
           

            return Response(data="Departement and materiel and porte deleted", status=status.HTTP_200_OK)

        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)



class DepartementCreate(APIView):
    # parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        departement_serializer = DepartementCreateAndUpdateSerializer(data=request.data)
        if departement_serializer.is_valid():
            departement_serializer.save()
            return Response(departement_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(departement_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AssignUserToDepartement(APIView):
    def get_object(self, pk):
        try:
            return Departement.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404

    def post(self, request, pk, format=None):
        try: 
            departement = self.get_object(pk)
            departement.users.add(request.data['user_id'])
            departement.save()
            return Response(data="User added to departement", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)


class AssignUsersToDepartement(APIView):
    def get_object(self, pk):
        try:
            return Departement.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404

    def post(self, request, pk, format=None):
        try:
            dep = self.get_object(pk)
            dep.users.add(*request.data['users'])
            dep.save()
            return Response(data="Users added to dept", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)

class RemoveUserFromDepart(APIView):
    def get_object(self, pk):
        try:
            return Departement.objects.get(pk=pk)
        except Departement.DoesNotExist:
            raise Http404

    def post(self, request, pk, format=None):
        try:
            dep = self.get_object(pk)
            dep.users.remove(request.data['user_id'])
            dep.save()
            return Response(data="User removed from dept", status=status.HTTP_200_OK)
        except Exception as e:
            print(e)
            return Response(data={"message": e.__str__()}, status=status.HTTP_400_BAD_REQUEST)