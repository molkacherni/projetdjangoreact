from django.contrib import admin
from .models import Presence, Departement, Porte, Materiel, DataSetPics, PicturePointage, PresenceDay
# Register your models here.

admin.site.register(PresenceDay)
admin.site.register(Presence)
admin.site.register(Departement)
admin.site.register(Porte)
admin.site.register(Materiel)
admin.site.register(DataSetPics)
admin.site.register(PicturePointage)

