from pointage.models import Presence, Porte, Departement, Materiel, DataSetPics, PicturePointage, PresenceDay
from pointage.serializers.presence import PresenceSerializer, PresenceDaySerializer


def presence_schedule():
    print('hello')