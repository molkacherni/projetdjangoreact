from pointage.models import Presence, Porte, Departement, Materiel, DataSetPics, PicturePointage, PresenceDay
from pointage.serializers.presence import PresenceSerializer, PresenceDaySerializer, PresenceSerializerWithouPresences
from user.models import User
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser
from django.http import Http404
from .dataset_pic_serializer import DataSetPicsSerializer
from .picture_seriliazer import PicturePointageSerializer
from datetime import datetime
from django.utils import timezone
from time import time
from django.db.models import Sum
from datetime import timedelta
from dateutil.relativedelta import *
from django.core.mail import send_mail
from django.conf import settings
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.core.mail import EmailMessage
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from user.serializers import UserSerializer


class StaticsControl(APIView):
    def get(self, request, format=None):
        try : 
            data = {}
            data['porte'] = Porte.objects.count()
            data['departement'] = Departement.objects.count()
            data['materiel'] = Materiel.objects.count()
            data['user'] = User.objects.filter(is_deleted=False).count()
            data['presence'] = Presence.objects.count()
            data['super_admins'] = User.objects.filter(role=1).count()
            data['rhs'] = User.objects.filter(role=2).count()
            data['employees'] = User.objects.filter(role=3).count()
            return Response(data)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class CreateDataSetPics(APIView):

    parser_classes = (FormParser, MultiPartParser)

    def get_object(self, pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist: 
            raise Http404


    def post(self, request, user_id, format=None):
        try: 
            print(user_id)
            data = request.data
            user = self.get_object(user_id)
            print(user)
            if user:
                DataSetPics.objects.create(user=user, picture_1=data['picture_1'], picture_2=data['picture_2'], picture_3=data['picture_3'], picture_4=data['picture_4'], picture_5=data['picture_5'], picture_6=data['picture_6'], picture_7=data['picture_7'], picture_8=data['picture_8'], picture_9=data['picture_9'], picture_10=data['picture_10'])
                return Response({'message': 'data set created'}, status=status.HTTP_201_CREATED)
            return Response({'message': 'user not found'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, user_id, format=None):
        user = user = self.get_object(user_id)
        dataset = DataSetPics.objects.get(user=user_id)
        serializer = DataSetPicsSerializer(dataset)
        return Response(serializer.data)


class PicCreate(APIView):
    
    def post(self, request, format=None):
        ##Create picuttre usin PictureSerializer
        print(request.data)
        try:
            serializer = PicturePointageSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) 
        except Exception as e:
            print(e)
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AuthWithFaceAndGestureRecognition(APIView):
    def post(self, request, format=None):
        try : 
            pic_name = request.data['pic_name']
            porte_id = request.data['porte_id']
            pic = PicturePointage.objects.get(pic_name=pic_name)
            if pic:
                user = pic.user
                print(user)
                if user:
                    ##find presence day of user with today date
                    try:
                        presence_day = PresenceDay.objects.get(user=user, date=timezone.now().date())
                        try:
                            presence = Presence.objects.get(presence_day=presence_day, heure_fin=None)
                            presence.heure_fin = timezone.now()
                            presence.save()
                            return Response({'message': 'presence updated'}, status=status.HTTP_200_OK)
                        except Presence.DoesNotExist:
                            porte = Porte.objects.get(pk=porte_id)
                            Presence.objects.create(presence_day=presence_day, heure_debut=timezone.now(), porte=porte)
                            return Response({'message': 'presence created'}, status=status.HTTP_201_CREATED)

                    except PresenceDay.DoesNotExist:
                        p_day = PresenceDay.objects.create(user=user, date=timezone.now().date())
                        ##Create presence
                        porte = Porte.objects.get(pk=porte_id)
                        Presence.objects.create(heure_debut=timezone.now(), presence_day=p_day, porte=porte)
                        return Response({'message': 'presence created'}, status=status.HTTP_201_CREATED)
                        
                  
                        
                else:
                    return Response({'message': 'user not found'}, status=status.HTTP_404_NOT_FOUND)
            else:
                return Response({'message': 'picture not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class GetPresencesDays(ListAPIView):
    serializer_class = PresenceDaySerializer
    queryset = PresenceDay.objects.all()

def diff_times_in_seconds(t1, t2):
    # caveat emptor - assumes t1 & t2 are python times, on the same day and t2 is after t1
    h1, m1, s1 = t1.hour, t1.minute, t1.second
    h2, m2, s2 = t2.hour, t2.minute, t2.second
    t1_secs = s1 + 60 * (m1 + 60*h1)
    t2_secs = s2 + 60 * (m2 + 60*h2)
    return( t2_secs - t1_secs)
        

class TestingView(APIView):
    def get(self, request, format=None):
        ##For every presence day, find first presence and last presence
        presence_days = PresenceDay.objects.all()
        presence_days_data = PresenceDaySerializer(presence_days, many=True).data
        # print(presence_days_data)
        presence_days_general_debut_fin = []
        # for presence_day in presence_days_data:
        #     print(presence_day["id"])

        for presence_day in presence_days_data:

            presences = Presence.objects.filter(presence_day=presence_day["id"])
            pr = PresenceDay.objects.get(id=presence_day["id"])

            presences_data = PresenceSerializerWithouPresences(presences, many=True).data
            ##find presence with lowest heure_debut
            ##convert presences orderedDict to dict
            presences_data = [dict(presence) for presence in presences_data]
            first_presence = presences_data[0]
            last_presence = presences_data[0]
            
            for presence in presences_data:
                if presence["heure_debut"] < first_presence["heure_debut"]:
                    first_presence = presence
                if presence["heure_fin"] > last_presence["heure_fin"]:
                    last_presence = presence
            
            if first_presence["heure_debut"] and last_presence["heure_fin"]:
                pr.present = True
            else:
                pr.present = False
                
            

            ##convert first_presence["heure_debut"] which is string to time
            #ValueError: unconverted data remains: .062306
            first_presence_time = datetime.strptime(first_presence["heure_debut"], '%H:%M:%S.%f').time()
            last_presence_time = datetime.strptime(last_presence["heure_fin"], '%H:%M:%S.%f').time()
            print(first_presence["heure_debut"])
            print(type(first_presence_time))
            print(type(last_presence_time))

            #8h00 time 
            h_8_00 = datetime.strptime('08:0:00.000000', '%H:%M:%S.%f').time()
            ##17h00 time
            h_17_00 = datetime.strptime('17:0:00.000000', '%H:%M:%S.%f').time()
            # now = datetime.now()
            # h_8_00 = now.replace(hour=8, minute=0, second=0, microsecond=0).time()
            # h_17_00 = now.replace(hour=17, minute=0, second=0, microsecond=0).time()
            
            print(type(h_8_00))
            print(type(h_17_00))

            




            if first_presence_time > h_8_00:
                pr.is_late = True
                pr.late_time = diff_times_in_seconds(h_8_00, first_presence_time) / 3600
            else:
                pr.is_late = False
                pr.late_time = 0
            
            if last_presence_time < h_17_00:
                pr.early_leaving = True
                pr.overtime_time = 0
                ##calculate early leaving time
                pr.early_leaving_time = diff_times_in_seconds(last_presence_time, h_17_00) / 3600
                pr.overtime = False
            else:
                ##the overtime time is the sum of the difference between heure_debut and heure_fin that are greater than 17h00

                ##calculate overtime time

                ##find presences with heure_debut less than 17h00 and heure_fin greater than 17h00
                extra = 0
                try : 
                    presence_less_17h00_greater_17h00 = Presence.objects.get(presence_day=presence_day["id"], heure_debut__lt=h_17_00, heure_fin__gt=h_17_00)
                    extra = diff_times_in_seconds(h_17_00, presence_less_17h00_greater_17h00.heure_fin) / 3600
                except Presence.DoesNotExist:
                    pass




                ##get all presences that have heure_debut greater than 17h00
                presences_after_17h00 = Presence.objects.filter(presence_day=presence_day["id"], heure_debut__gt=h_17_00)
                presences_after_17h00_data = PresenceSerializerWithouPresences(presences_after_17h00, many=True).data
                ##convert presences orderedDict to dict
                presences_after_17h00_data = [dict(presence) for presence in presences_after_17h00_data]
                overtime_time = 0
                for presence in presences_after_17h00_data:
                    heure_debut_time = datetime.strptime(presence["heure_debut"], '%H:%M:%S.%f').time()
                    heure_fin_time = datetime.strptime(presence["heure_fin"], '%H:%M:%S.%f').time()
                    overtime_time += diff_times_in_seconds(heure_debut_time, heure_fin_time)
                pr.overtime_time = overtime_time / 3600 + extra



                pr.overtime = True
                ##calculate overtime time
                # pr.overtime_time = diff_times_in_seconds(h_17_00, last_presence_time) / 3600
                pr.early_leaving = False
                pr.early_leaving_time = 0

            ##calculate total time and covert it into hours number
            ## the sum of the diffetence between all the heure_debut and heure_fin of the presences
            total_time = 0
            for presence in presences_data:
                presence_time = diff_times_in_seconds(datetime.strptime(presence["heure_debut"], '%H:%M:%S.%f').time(), datetime.strptime(presence["heure_fin"], '%H:%M:%S.%f').time())
                total_time += presence_time
            pr.total_rest = total_time / 3600
            
            pr.save()

            

        return Response("Hello")
        # return Response(presence_days_data)
            


class FetchView(APIView):
    def get(self, request, format=None):
        ##For every presence day, find first presence and last presence
        presence_days = PresenceDay.objects.all()
        presence_days_data = PresenceDaySerializer(presence_days, many=True).data
        # print(presence_days_data)
        presence_days_general_debut_fin = []
        # for presence_day in presence_days_data:
        #     print(presence_day["id"])

        for presence_day in presence_days_data:

            presences = Presence.objects.filter(presence_day=presence_day["id"])
            presences_data = PresenceSerializerWithouPresences(presences, many=True).data
            ##find presence with lowest heure_debut
            ##convert presences orderedDict to dict
            presences_data = [dict(presence) for presence in presences_data]
            first_presence = presences_data[0]
            last_presence = presences_data[0]
            for presence in presences_data:
                if presence["heure_debut"] < first_presence["heure_debut"]:
                    first_presence = presence
                if presence["heure_fin"] > last_presence["heure_fin"]:
                    last_presence = presence
            presence_days_general_debut_fin.append({
                'presence_day':{
                    'id': presence_day["id"],
                    'date': presence_day["date"],
                    'user': presence_day["user"]
                },
                'first_presence': first_presence,
                'last_presence': last_presence
            })
        return Response(presence_days_general_debut_fin)
        # return Response(presence_days_data)
            


            
class UsersPresenceStatics(APIView):
    def get(self, request, format=None):
        users = User.objects.all()

        statics = []
        for user in users:
            count_presences_day_is_present = PresenceDay.objects.filter(user=user.id, present=True).count()
            count_presences_day_is_absent = PresenceDay.objects.filter(user=user.id, present=False).count()
            count_presences_day_is_late = PresenceDay.objects.filter(user=user.id, is_late=True).count()
            count_presences_day_is_early_leaving = PresenceDay.objects.filter(user=user.id, early_leaving=True).count()
            count_presences_day_is_overtime = PresenceDay.objects.filter(user=user.id, overtime=True).count()
            total_rest = PresenceDay.objects.filter(user=user.id).aggregate(Sum('total_rest'))['total_rest__sum']
            total_overtime = PresenceDay.objects.filter(user=user.id).aggregate(Sum('overtime_time'))['overtime_time__sum']
            total_early_leaving = PresenceDay.objects.filter(user=user.id).aggregate(Sum('early_leaving_time'))['early_leaving_time__sum']
            total_late = PresenceDay.objects.filter(user=user.id).aggregate(Sum('late_time'))['late_time__sum']
            statics.append({
                'user_id': user.id,
                'user_full_name': user.first_name + " " + user.last_name,
                'user_matricule': user.matricule,
                'user_email': user.email,
                'count_presences_day_is_present': count_presences_day_is_present,
                'count_presences_day_is_absent': count_presences_day_is_absent,
                'count_presences_day_is_late': count_presences_day_is_late,
                'count_presences_day_is_early_leaving': count_presences_day_is_early_leaving,
                'count_presences_day_is_overtime': count_presences_day_is_overtime,
                'total_rest': 0 if total_overtime == None else total_overtime,
                'total_overtime': 0 if total_overtime == None else total_overtime,
                'total_early_leaving': 0 if total_early_leaving == None else total_early_leaving,
                'total_late': 0 if total_late == None else total_late,
            })
               
        return Response(statics)


class SingleUserStats(APIView):
    def get(self, request, user_id, format=None):
        user = User.objects.get(id=user_id)
        count_presences_day_is_present = PresenceDay.objects.filter(user=user.id, present=True).count()
        count_presences_day_is_absent = PresenceDay.objects.filter(user=user.id, present=False).count()
        count_presences_day_is_late = PresenceDay.objects.filter(user=user.id, is_late=True).count()
        count_presences_day_is_early_leaving = PresenceDay.objects.filter(user=user.id, early_leaving=True).count()
        count_presences_day_is_overtime = PresenceDay.objects.filter(user=user.id, overtime=True).count()
        total_rest = PresenceDay.objects.filter(user=user.id).aggregate(Sum('total_rest'))['total_rest__sum']
        total_overtime = PresenceDay.objects.filter(user=user.id).aggregate(Sum('overtime_time'))['overtime_time__sum']
        total_early_leaving = PresenceDay.objects.filter(user=user.id).aggregate(Sum('early_leaving_time'))['early_leaving_time__sum']
        total_late = PresenceDay.objects.filter(user=user.id).aggregate(Sum('late_time'))['late_time__sum']
        statics = {
            'user_id': user.id,
            'user_full_name': user.first_name + " " + user.last_name,
            'user_matricule': user.matricule,
            'user_email': user.email,
            'count_presences_day_is_present': count_presences_day_is_present,
            'count_presences_day_is_absent': count_presences_day_is_absent,
            'count_presences_day_is_late': count_presences_day_is_late,
            'count_presences_day_is_early_leaving': count_presences_day_is_early_leaving,
            'count_presences_day_is_overtime': count_presences_day_is_overtime,
            'total_rest': 0 if total_overtime == None else total_overtime,
            'total_overtime': 0 if total_overtime == None else total_overtime,
            'total_early_leaving': 0 if total_early_leaving == None else total_early_leaving,
            'total_late': 0 if total_late == None else total_late,
        }
               
        return Response(statics)

##Get today present and absent users
class UsersTodayPresence(APIView):
    def get(self, request, format=None):
        today = datetime.now().date()
        presence_days = PresenceDay.objects.filter(date=today)
        users = User.objects.all()
        users_today_presence = []
        for user in users:
            user_presence = False
            for presence_day in presence_days:
                if user.id == presence_day.user.id:
                    user_presence = True
                    break
            
            img = user.picture.url if user.picture else None

            users_today_presence.append({
                'user_id': user.id,
                'user_full_name': user.first_name + " " + user.last_name,
                'user_matricule': user.matricule,
                'user_profile_pic': img,
                'user_email': user.email,
                'user_presence': user_presence,
            })
              
        return Response(users_today_presence)

class UsersPresencesByDate(APIView):
    def get(self, request, date, format=None):
        date = datetime.strptime(date, '%Y-%m-%d').date()
        presence_days = PresenceDay.objects.filter(date=date)
        users = User.objects.all()
        users_today_presence = []
        for user in users:
            user_presence = False
            for presence_day in presence_days:
                if user.id == presence_day.user.id:
                    user_presence = True
                    break
            
            img = user.picture.url if user.picture else None

            users_today_presence.append({
                'user_id': user.id,
                'user_full_name': user.first_name + " " + user.last_name,
                'user_matricule': user.matricule,
                'user_profile_pic': img,
                'user_email': user.email,
                'user_presence': user_presence,
            })
              
        return Response(users_today_presence)

##count is present and absent users by date for 7 last days
# class UsersPresencesStatsLast7Days(APIView):
#     def get(self, request, format=None):
#         today = datetime.now
    


##User presence 7 last days
class UserPresenceLast7Days(APIView):
    def get(self, request, user_id, format=None):
        user = User.objects.get(id=user_id)
        today = datetime.now().date()
        last_7_days = []
        for i in range(7):
            day = today - timedelta(days=i)
            presence_day = PresenceDay.objects.filter(user=user.id, date=day)
            if presence_day:
                presence_day = presence_day[0]
                last_7_days.append({
                    'date': presence_day.date,
                    'present': presence_day.present,
                    'is_late': presence_day.is_late,
                    'early_leaving': presence_day.early_leaving,
                    'overtime': presence_day.overtime,
                    'total_rest': presence_day.total_rest,
                    'overtime_time': presence_day.overtime_time,
                    'early_leaving_time': presence_day.early_leaving_time,
                    'late_time': presence_day.late_time,
                })
            else:
                last_7_days.append({
                    'date': day,
                    'present': False,
                    'is_late': False,
                    'early_leaving': False,
                    'overtime': False,
                    'total_rest': 0,
                    'overtime_time': 0,
                    'early_leaving_time': 0,
                    'late_time': 0,
                })
        return Response(last_7_days)


class CalculateUserPresenceMonthlyAndYearly(APIView):
    def get(self, request, user_id, format=None):
        user = User.objects.get(id=user_id)
        today = datetime.now().date()
        last_12_months = []
        for i in range(12):
            month = today - relativedelta(months=i)
            presence_days = PresenceDay.objects.filter(user=user.id, date__month=month.month, date__year=month.year)
            count_presences_day_is_present = presence_days.filter(present=True).count()
            count_presences_day_is_absent = presence_days.filter(present=False).count()
            count_presences_day_is_late = presence_days.filter(is_late=True).count()
            count_presences_day_is_early_leaving = presence_days.filter(early_leaving=True).count()
            count_presences_day_is_overtime = presence_days.filter(overtime=True).count()
            total_rest = presence_days.aggregate(Sum('total_rest'))['total_rest__sum']
            total_overtime = presence_days.aggregate(Sum('overtime_time'))['overtime_time__sum']
            total_early_leaving = presence_days.aggregate(Sum('early_leaving_time'))['early_leaving_time__sum']
            total_late = presence_days.aggregate(Sum('late_time'))['late_time__sum']
            last_12_months.append({
                'month': month.month,
                'year': month.year,
                'count_presences_day_is_present': count_presences_day_is_present,
                'count_presences_day_is_absent': count_presences_day_is_absent,
                'count_presences_day_is_late': count_presences_day_is_late,
                'count_presences_day_is_early_leaving': count_presences_day_is_early_leaving,
                'count_presences_day_is_overtime': count_presences_day_is_overtime,
                'total_rest': 0 if total_overtime == None else total_overtime,
                'total_overtime': 0 if total_overtime == None else total_overtime,
                'total_early_leaving': 0 if total_early_leaving == None else total_early_leaving,
                'total_late': 0 if total_late == None else total_late,
            })
        return Response(last_12_months)

@api_view(('POST',))
@renderer_classes((JSONRenderer, ))
##receive files
def email(request):
    try:
        ##now time with seconds


        rh_users = UserSerializer(User.objects.filter(is_deleted=False, role=2), many=True).data
        rh_mails = []
        for rh_user in rh_users:
            rh_mails.append(rh_user['email'])

        access_time = str(datetime.now().time())
        ##get argument door from request url
        door = request.data['door']

        ##check request files
        binary_file_data = ''
        file_url = ''
        file_path = ''
        # if 'image' in request.FILES:
        #     # print(request.FILES['image'])
        #     ##save it and then attach it to email
        #     binary_file_data = request.FILES['image'].read()
        #     ##get file url
        #     file_url = default_storage.save('media/' + access_time + '.jpg', ContentFile(binary_file_data))
        #     print(file_url)
        #     ##get file path
        #     file_path = default_storage.path(file_url)
        #     print(file_path)
        #     ##get file and attach it to email
        #     file = open(file_path, 'rb')
        #     file_data = file.read()
        #     file.close()


        subject = 'Alerte de sécurité'
        message = 'Quelqu\'un a non autorisé a essayé d\'accéder à la porte ' + door + ' à ' + access_time + ' .'
        email_from = settings.EMAIL_HOST_USER
        

        email = EmailMessage(subject, message, email_from, rh_mails)
        # print(binary_file_data)
        ##attach file to email
        if 'image' in request.FILES:
            upload_file = request.FILES['image']
            email.attach(upload_file.name, upload_file.read(), upload_file.content_type)
        email.send()
        return Response({'message': 'email sent'})
    except Exception as e:
        return Response({'message': str(e)})

##Post logo image and save it
@api_view(('POST',))
@renderer_classes((JSONRenderer, ))
def logo(request):
    try:
        ##get argument door from request url
        ##check request files
        name = 'logo'
        if 'logo' in request.FILES:
            ##save it and then attach it to email

            ##delete current file with same name if exist
            

            binary_file_data = request.FILES['logo'].read()
            ##get file url
            ##get file extension
            file_extension = request.FILES['logo'].name.split('.')[-1]
            ##delete current file with same name if exist with default_storage
            if default_storage.exists('logo/' + name + '.' + file_extension):
                default_storage.delete('logo/' + name + '.' + file_extension)
            file_url = default_storage.save('logo/' + name + '.' + file_extension, ContentFile(binary_file_data))
            ##get file path
            file_path = default_storage.path(file_url)
            ##get file and attach it to email
            file = open(file_path, 'rb')
            file_data = file.read()
            file.close()
            return Response({'message': 'logo saved'})
        else:
            return Response({'message': 'logo not saved'})
    except Exception as e:
        return Response({'message': str(e)})