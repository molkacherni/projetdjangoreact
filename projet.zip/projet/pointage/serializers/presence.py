from pointage.models import Presence, PresenceDay
from user.serializers import UserSerializer
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group
from rest_framework_simplejwt.settings import api_settings
from .porte import PorteSerilizerWithTheirDepartements


class MainPresenceDaySerializer(serializers.ModelSerializer):

    user = serializers.SerializerMethodField('get_user')

    class Meta:
        model = PresenceDay
        fields = ['id', 'date', 'user', 'present', 'early_leaving', 'overtime', 'total_rest', 'early_leaving_time', 'overtime_time']

    def get_user(self, obj):
        return UserSerializer(obj.user).data




class PresenceSerializer(serializers.ModelSerializer):

    main_presence_day = serializers.SerializerMethodField('get_main_presence_day')

    class Meta:
        model = Presence
        fields = ['id', 'heure_debut', 'heure_fin', 'main_presence_day', 'porte']


    def get_main_presence_day(self, obj):
        ##Query database and return main_presence_day
        return MainPresenceDaySerializer(obj.presence_day).data



class PresenceSerializerWithouPresences(serializers.ModelSerializer):

    porte = serializers.SerializerMethodField('get_porte')

    class Meta:
        model = Presence
        fields = ['id', 'heure_debut', 'heure_fin', 'porte']

    def get_porte(self, obj):
        return PorteSerilizerWithTheirDepartements(obj.porte).data

class PresenceDaySerializer(serializers.ModelSerializer):

    user = serializers.SerializerMethodField('get_user')
    presences = serializers.SerializerMethodField('get_presences')

    class Meta:
        model = PresenceDay
        fields = ['id', 'date', 'user', 'presences', 'present', 'early_leaving', 'overtime', 'total_rest', 'early_leaving_time', 'overtime_time']

    def get_user(self, obj):
        return UserSerializer(obj.user).data

    def get_presences(self, obj):
        ##find all presences of this day
        presences_list = Presence.objects.filter(presence_day=obj)
        return PresenceSerializerWithouPresences(presences_list, many=True).data


