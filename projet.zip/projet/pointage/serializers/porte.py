from pointage.models import Porte, Departement
from pointage.serializers.departement import DepartementSerializer
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group
from rest_framework_simplejwt.settings import api_settings
from user.serializers import UserSerializer

class PorteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Porte
        fields = ['id', 'name', 'departement', 'is_open']

class PorteSerilizerWithTheirDepartements(serializers.ModelSerializer):

    departement = serializers.SerializerMethodField('get_departement')
    users = serializers.SerializerMethodField('get_users')
    class Meta:
        model = Porte
        fields = ['id', 'name', 'departement', 'users', 'is_open']

    def get_departement(self, obj):
        departement = Departement.objects.get(id=obj.departement.id)
        serializer = DepartementSerializer(departement)
        return serializer.data

    def get_users(self, obj):
        users = obj.users.all()
        serializer = UserSerializer(users, many=True)
        return serializer.data


class PorteDeleteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Porte
        fields = ['id', 'is_deleted']