from pointage.models import Departement
from user.serializers import UserSerializer
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group
from rest_framework_simplejwt.settings import api_settings

class DepartementSerializer(serializers.ModelSerializer):

    users = serializers.SerializerMethodField('get_users')

    class Meta:
        model = Departement
        fields = ['id', 'name', 'users']

    def get_users(self, obj):
        users = obj.users.all()
        serializer = UserSerializer(users, many=True)
        return serializer.data




class DepartementCreateAndUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Departement
        fields = ['id', 'name']

class DepartementDeleteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Departement
        fields = ['id', 'is_deleted']