from pointage.models import Materiel, Porte
from pointage.serializers.porte import PorteSerilizerWithTheirDepartements
from rest_framework import serializers
from rest_framework.validators import UniqueValidator

class MaterielSerializer(serializers.ModelSerializer):
    class Meta:
        model = Materiel
        fields = ['id', 'porte', 'reference', 'emplacement', 'etat']
    

class MaterialSerializerWithTheirPorte(serializers.ModelSerializer):
    porte = serializers.SerializerMethodField('get_porte')
    class Meta:
        model = Materiel
        fields = ['id', 'porte', 'reference', 'emplacement', 'etat']
    
    def get_porte(self, obj):
        porte = Porte.objects.get(id=obj.porte.id)
        serializer = PorteSerilizerWithTheirDepartements(porte)
        return serializer.data


class MaterielDeleteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Materiel
        fields = ['id', 'is_deleted']