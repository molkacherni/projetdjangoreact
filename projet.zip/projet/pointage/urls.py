from django.urls import path
from .views.presence import (
    ListPresence,
    PresenceControl,
    PresenceCreate,
    Test
)

from .views.departement import (
    ListDepartement,
    DepartementControl,
    DepartementCreate,
    AssignUserToDepartement,
    AssignUsersToDepartement,
    RemoveUserFromDepart
)

from .views.porte import (
    ListPorte,
    PorteControl,
    PorteCreate,
    AssignManyUsersToPorte,
    RemoveUserFromPorte,
    ToggleOpenDoor,
    ListePorteWithTheirUsersAndThirPictures
)

from .views.materiel import (
    ListMateriel,
    MaterielControl,
    MaterielCreate,
)

from .main_views import (
    StaticsControl,
    CreateDataSetPics,
    PicCreate,
    AuthWithFaceAndGestureRecognition,
    GetPresencesDays,
    TestingView,
    UsersPresenceStatics,
    SingleUserStats,
    UsersTodayPresence,
    UsersPresencesByDate,
    UserPresenceLast7Days,
    CalculateUserPresenceMonthlyAndYearly,
    email,
    logo
)

from rest_framework_simplejwt import views as jwt_views
from django.conf.urls.static import static 
from django.conf import settings


app_name = "pointage"

urlpatterns = [
    path('presence/list', ListPresence.as_view(), name="list_presence"),
    path('presence/<int:pk>', PresenceControl.as_view(), name="control_presence"),
    path('departement/list', ListDepartement.as_view(), name="list_departement"),
    path('departement/<int:pk>', DepartementControl.as_view(), name="control_departement"),
    path('porte/list', ListPorte.as_view(), name="list_porte"),
    path('porte/<int:pk>', PorteControl.as_view(), name="control_porte"),
    path('materiel/list', ListMateriel.as_view(), name="list_materiel"),
    path('materiel/<int:pk>', MaterielControl.as_view(), name="control_materiel"),
    path('presence/create', PresenceCreate.as_view(), name="create_presence"),
    path('departement/create', DepartementCreate.as_view(), name="create_departement"),
    path('porte/create', PorteCreate.as_view(), name="create_porte"),
    path('materiel/create', MaterielCreate.as_view(), name="create_materiel"),
    path('statics', StaticsControl.as_view(), name="statics"),
    path('assign_user_to_departement/<int:pk>', AssignUserToDepartement.as_view(), name="assign_user_to_departement"),
    path('dataset_pic/<int:user_id>', CreateDataSetPics.as_view(), name="dataset_pic"),
    path('assign_many_users_to_porte/<int:pk>', AssignManyUsersToPorte.as_view(), name="assign_many_users_to_porte"),
    path('remove_user_from_porte/<int:pk>', RemoveUserFromPorte.as_view(), name="remove_user_from_porte"),
    path('assign_users_to_departement/<int:pk>', AssignUsersToDepartement.as_view(), name="assign_users_to_departement"),
    path('remove_user_from_depart/<int:pk>', RemoveUserFromDepart.as_view(), name="remove_user_from_depart"),
    path('picture/create', PicCreate.as_view(), name="picture"),
    path('test', Test.as_view(), name="test"),
    path('recognition', AuthWithFaceAndGestureRecognition.as_view(), name="auth"),
    path('get_presences_days', GetPresencesDays.as_view(), name="get_presences_days"),
    path('testing', TestingView.as_view(), name="testing"),
    path('toggle_open_door/<int:pk>', ToggleOpenDoor.as_view(), name="toggle_open_door"),
    path('users_presence_statics', UsersPresenceStatics.as_view(), name="users_presence_statics"),
    path('single_user_stats/<int:pk>', SingleUserStats.as_view(), name="single_user_stats"),
    path('users_today_presence', UsersTodayPresence.as_view(), name="users_today_presence"),
    path('users_presences_by_date/<str:date>', UsersPresencesByDate.as_view(), name="users_presences_by_date"),
    path('user_presence_last_7_days/<int:user_id>', UserPresenceLast7Days.as_view(), name="user_presence_last_7_days"),
    path('calculate_user_presence_monthly_and_yearly/<int:user_id>', CalculateUserPresenceMonthlyAndYearly.as_view(), name="calculate_user_presence_monthly_and_yearly"),
    path('porte/list_with_users_and_pics', ListePorteWithTheirUsersAndThirPictures.as_view(), name="porte_list_with_users_and_pics"),
    path('email', email, name="email"),
    path('logo', logo, name="logo"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)