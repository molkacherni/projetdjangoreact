from .models import PicturePointage
from user.serializers import UserSerializer
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group


# class DataSetPicsSerializer(DynamicFieldsMixin, serializers.ModelSerializer):

#     user = serializers.SerializerMethodField('get_user')

#     class Meta:
#         model = DataSetPics
#         fields = ['id', 'user', 'picture_1', 'picture_2', 'picture_3', 'picture_4', 'picture_5', 'picture_6', 'picture_7', 'picture_8', 'picture_9', 'picture_10']

#     def get_user(self, obj):
#         user = obj.user
#         serializer = UserSerializer(user)
#         return serializer.data


class PicturePointageSerializer(DynamicFieldsMixin, serializers.ModelSerializer):

    class Meta:
        model = PicturePointage
        fields = ['id', 'pic_name', 'user']


class PicturePointageSerializerName(DynamicFieldsMixin, serializers.ModelSerializer):

    class Meta:
        model = PicturePointage
        fields = ['pic_name']
