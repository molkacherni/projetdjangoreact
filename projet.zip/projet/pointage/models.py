from django.db import models
from user.models import User

# Create your models here.
class PresenceDay(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    present = models.BooleanField(default=False, blank=True, null=True)
    early_leaving = models.BooleanField(default=False, blank=True, null=True)
    early_leaving_time = models.DecimalField(max_digits=4, decimal_places=2, blank=True, null=True)
    overtime = models.BooleanField(default=False, blank=True, null=True)
    overtime_time = models.DecimalField(max_digits=4, decimal_places=2, blank=True, null=True)
    total_rest = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True)
    is_late = models.BooleanField(default=False, blank=True, null=True)
    late_time = models.DecimalField(max_digits=4, decimal_places=2, blank=True, null=True)

    # def __str__(self):
    #     return self.user.username

class Presence(models.Model):
  presence_day = models.ForeignKey(PresenceDay, on_delete=models.CASCADE, blank=True, null=True)
  heure_debut = models.TimeField(null=True, blank=True)
  heure_fin = models.TimeField(null=True, blank=True)
  porte = models.ForeignKey('Porte', on_delete=models.CASCADE, blank=True, null=True)



class Departement(models.Model):
    name = models.CharField(max_length=100)
    users = models.ManyToManyField(User, related_name='departement')
    is_deleted = models.BooleanField(default=False)



class Porte(models.Model):
  name = models.CharField(max_length=100)
  departement = models.ForeignKey('Departement', on_delete=models.CASCADE)
  is_deleted = models.BooleanField(default=False)
  is_open = models.BooleanField(default=False)
  users = models.ManyToManyField(User, related_name='porte')



class Materiel(models.Model):
  porte = models.OneToOneField(Porte, on_delete=models.CASCADE)
  reference = models.IntegerField()
  emplacement = models.CharField(max_length=100)
  etat = models.BooleanField(default=False)
  is_deleted = models.BooleanField(default=False)


class DataSetPics(models.Model):
    user = models.ForeignKey('user.User', on_delete=models.CASCADE)
    picture_1 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_2 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_3 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_4 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_5 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_6 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_7 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_8 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_9 = models.ImageField(upload_to='pics_dataset', blank=True)
    picture_10 = models.ImageField(upload_to='pics_dataset', blank=True)
  
  
class PicturePointage(models.Model):
      user = models.ForeignKey('user.User', on_delete=models.CASCADE)
      pic_name = models.CharField(max_length=100)

      def __str__(self):
        return f"{self.pic_name}"




  