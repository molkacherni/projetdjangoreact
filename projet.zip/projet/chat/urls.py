from django.urls import path

from . import views


app_name = "chat"


urlpatterns = [
    path('messages/<int:room_id>/', views.MessageList.as_view(), name='messages'),
    path('create_room/', views.CreateRoom.as_view(), name='create_room'),
    path('room/<int:pk>/', views.RoomControl.as_view(), name='room'),
    path('rooms/', views.RoomsList.as_view(), name='rooms'),
]