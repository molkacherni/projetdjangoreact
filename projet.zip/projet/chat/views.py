from django.shortcuts import render
from .models import Room, Message
from .serializers import MessageRoomSerializer, CreateRoomSerializer, RoomSerializer
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser
from django.http import Http404


class MessageList(APIView):

    def get(self, request, room_id, format=None):
        room = Room.objects.get(pk=room_id)
        messages = Message.objects.filter(room=room)
        serializer = MessageRoomSerializer(messages, many=True)
        ##transform the data to a list of dictionaries
        data = serializer.data
        ##reverse the list
        data.reverse()
        return Response(data)

        
    def post(self, request, format=None):
        serializer = MessageRoomSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CreateRoom(APIView):

    def post(self, request, format=None):
        serializer = CreateRoomSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RoomsList(APIView):

    def get(self, request, format=None):
        rooms = Room.objects.all()
        serializer = RoomSerializer(rooms, many=True)
        ##get the last message in each room
        rooms_list = []
        for room in serializer.data:
            room_last_message = Message.objects.filter(room=room['id']).last()
            room['last_message'] = MessageRoomSerializer(room_last_message).data
            rooms_list.append(room)





        return Response(rooms_list)


class RoomControl(APIView):

    def get_object(self, pk):
        try:
            return Room.objects.get(pk=pk)
        except Room.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        room = self.get_object(pk)
        serializer = RoomSerializer(room)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        room = self.get_object(pk)
        serializer = RoomSerializer(room, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        room = self.get_object(pk)
        room.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



        