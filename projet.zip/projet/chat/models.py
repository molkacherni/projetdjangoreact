from django.db import models

# Create your models here.

class Room(models.Model):
    name = models.CharField(max_length=100)
    is_deleted = models.BooleanField(default=False)
    users = models.ManyToManyField('user.User', related_name='room')

class Message(models.Model):
    contenu_message = models.TextField()
    date_message = models.DateTimeField(auto_now_add=True)
    room = models.ForeignKey('Room', on_delete=models.CASCADE)
    sender = models.ForeignKey('user.User', on_delete=models.CASCADE)
    is_deleted = models.BooleanField(default=False)



