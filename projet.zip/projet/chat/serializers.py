# from .models import User
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group
from rest_framework_simplejwt.settings import api_settings
from .models import Room, Message
from user.serializers import UserSerializer


class MessageRoomSerializer(serializers.ModelSerializer):

    sender = serializers.SerializerMethodField('get_sender')

    class Meta:
        model = Message
        fields = ['id', 'contenu_message', 'date_message', 'room', 'sender']

    def get_sender(self, obj):
        sender = obj.sender
        serializer = UserSerializer(sender)
        return serializer.data

class RoomSerializer(serializers.ModelSerializer):

    users = serializers.SerializerMethodField('get_users')

    class Meta:
        model = Room
        fields = ['id', 'name', 'is_deleted', 'users']

    def get_users(self, obj):
        users = obj.users.all()
        serializer = UserSerializer(users, many=True)
        return serializer.data


class CreateRoomSerializer(serializers.ModelSerializer):

    class Meta:
        model = Room
        fields = ['name', 'users']

    def create(self, validated_data):
        users = validated_data.pop('users')
        room = Room.objects.create(**validated_data)
        for user in users:
            room.users.add(user)
        return room