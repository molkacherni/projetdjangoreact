from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.generics import CreateAPIView, ListAPIView
from .serializers import RegistrationSerializer, MyTokenObtainPairSerializer, UserSerializer, PutUserSerializer, UploadPictureSerializer, DeleteUserSerializer, UserSerializerWithDepartement, UpdateUserPasswordSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from .models import User
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.pagination import PageNumberPagination
from django.http import Http404
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.parsers import MultiPartParser, FormParser



class UserRegisterView(CreateAPIView):
  serializer_class = RegistrationSerializer

  def post(self, request, format=None):
    serializer = self.get_serializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()
    data = {
      "Response": "User registred successfully",
      "email": user.email,
      "full_name": user.first_name + " " + user.last_name,
    }
    return Response(data)

  def get_serializer(self, *args, **kwargs):
        serializer_class = self.get_serializer_class()
        kwargs['context'] = self.get_serializer_context()
        return serializer_class(*args, **kwargs)

class ListUsers(ListAPIView):
  serializer_class = UserSerializerWithDepartement
  queryset = User.objects.filter(is_deleted=False)
  # authentication_classes = (JWTAuthentication,)
  # permission_classes = (IsAuthenticated,)
  # pagination_class = PageNumberPagination


class UserControl(APIView):
  def get_object(self, pk):
    try:
      return User.objects.get(pk=pk)
    except User.DoesNotExist: 
      raise Http404

  def get(self, request, pk, format=None):
    user = self.get_object(pk)
    serializer = UserSerializerWithDepartement(user)
    return Response(serializer.data)

  def put(self, request, pk, format=None):
    user = self.get_object(pk)
    serializer = PutUserSerializer(user, data=request.data)
    if serializer.is_valid():
      serializer.save()
      return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

  def delete(self, request, pk, format=None):
    user = self.get_object(pk)
    delete_data = {
      "is_deleted": True
    }
    serializer = DeleteUserSerializer(user, data=delete_data)
    if serializer.is_valid():
      serializer.save()
      return Response({"Response": "User deleted successfully"})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    
class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer

class LogoutAPIView(APIView):
    permission_classes = (IsAuthenticated,)
    authentication_classes = (JWTAuthentication, )

    

    def post(self, request):
        try:
            refresh_token = request.data["refresh_token"]
            token = RefreshToken(refresh_token)
            token.blacklist()

            return Response({"success":"logged out successfully"},status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response({"error":"something went wrong"},status=status.HTTP_400_BAD_REQUEST)


class UploadUserProfilePicture(APIView):
    parser_classes = (FormParser, MultiPartParser)

    def get_object(self, pk):
      try:
        return User.objects.get(pk=pk)
      except User.DoesNotExist: 
        raise Http404

    def post(self, request, pk, *args, **kwargs): 



        user = self.get_object(pk)
        serializer = UploadPictureSerializer(user, data=request.data)

        if serializer.is_valid():
            print(serializer.validated_data.get('picture'))
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateUserPassword(APIView):

  def get_object(self, pk):
    try: 
      return User.objects.get(pk=pk)
    except User.DoesNotExist:
      raise Http404

  def put(self, request, pk, format=None):
    user = self.get_object(pk)

    ##check old password before updating
    if not user.check_password(request.data['old_password']):
      return Response({"error": "Old password is incorrect"}, status=status.HTTP_400_BAD_REQUEST)


    serializer = UpdateUserPasswordSerializer(user, data=request.data)
    if serializer.is_valid():
      serializer.save(pk)
      return Response({"Success": "Password updated successfully"}, status=status.HTTP_200_OK)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# class UploadUserProfilePicture(APIView):
#     parser_classes = (FormParser, MultiPartParser)

#     def get_object(self, pk):
#       try:
#         return User.objects.get(pk=pk)
#       except User.DoesNotExist: 
#         raise Http404

#     def post(self, request, pk, *args, **kwargs): 



#         user = self.get_object(pk)
#         print(request.data.get('picture'))
#         try:
#           if 'picture' in request.data:
#               user.picture.delete()
#               upload = request.data['picture']
              
#               user.picture.save(upload.name, upload, save=True)
#               return Response(status=status.HTTP_201_CREATED)
#           else:
#               return Response(status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             return Response(status=status.HTTP_400_BAD_REQUEST, data={'error': str(e)})

