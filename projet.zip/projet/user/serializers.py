from .models import User
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django_restql.mixins import DynamicFieldsMixin
from django.contrib.auth.models import Group
from rest_framework_simplejwt.settings import api_settings
from pointage.models import Departement


class RegistrationSerializer(serializers.ModelSerializer):
    
    password2 = serializers.CharField(style={"input_type": "password"}, write_only=True)
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'password', 'password2', 'matricule', 'role', 'gender', 'date_of_birth', 'phone_number', 'address', 'post']
        extract_kwargs = {
          'password': {'write_only': True}
        }
    
    def save(self):
      user = User(
        email=self.validated_data["email"],
        first_name=self.validated_data["first_name"],
        last_name=self.validated_data["last_name"],
        matricule=self.validated_data["matricule"],
        role=self.validated_data["role"],
        gender=self.validated_data["gender"],
        date_of_birth=self.validated_data["date_of_birth"],
        phone_number=self.validated_data["phone_number"],
        address=self.validated_data["address"],
        post=self.validated_data["post"],
      )
      password = self.validated_data["password"]
      password2 = self.validated_data["password2"]

      
      if password != password2:
        raise serializers.ValidationError({'password': 'Password Must Match'})
      if password == user.email:
        raise serializers.ValidationError({'password': 'Password must be different of email'})
      if len(password) < 8:
        raise serializers.ValidationError({'password': 'Password length must be over 8 charachters'})
      user.set_password(password)
      user.save()
      return user

class UpdateUserPasswordSerializer(serializers.ModelSerializer):
    password2 = serializers.CharField(style={"input_type": "password"}, write_only=True)
    class Meta:
      model = User
      fields = ['password', 'password2']
      extract_kwargs = {
        'password': {'write_only': True}
      }

    def save(self, pk):
      user = User.objects.get(pk=pk)
      password = self.validated_data["password"]
      password2 = self.validated_data["password2"]
      if password != password2:
        raise serializers.ValidationError({'password': 'Password Must Match'})
      if password == user.email:
        raise serializers.ValidationError({'password': 'Password must be different of email'})
      if len(password) < 8:
        raise serializers.ValidationError({'password': 'Password length must be over 8 charachters'})
      user.set_password(password)
      user.save()
      return user

 
      
class UserSerializerWithDepartement(DynamicFieldsMixin, serializers.ModelSerializer):
    department = serializers.SerializerMethodField('get_department')
    portes = serializers.SerializerMethodField('get_portes')
    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'matricule', 'role', 'gender', 'date_of_birth', 'phone_number', 'address', 'post', 'picture', 'department', 'portes']

    def get_department(self, obj):
        return obj.departement.all().values('id', 'name')

    def get_portes(self, obj):
        doors = obj.porte.all().values('id', 'name', 'departement')
        print(doors)
        ##get departement of each door
        for door in doors:
            departement = Departement.objects.get(id=door['departement'])
            door['departement'] = departement.name

        return doors

 
  

class UserSerializer(DynamicFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'matricule', 'role', 'gender', 'date_of_birth', 'phone_number', 'address', 'post', 'picture']




class PutUserSerializer(DynamicFieldsMixin, serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'matricule', 'role', 'gender', 'date_of_birth', 'phone_number', 'address', 'post']

class UploadPictureSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'picture']


class DeleteUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'is_deleted']

  
class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
  
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        #token['name'] = user.first_name + " " + user.last_name
        if user.role == 1:
          token['role'] = 'Super-Admin'
        elif user.role == 2:
          token['role'] = 'Rh'
        elif user.role == 3:
          token['role'] = 'Employee'

        return token

    def validate(self, attrs):
        data = super().validate(attrs)

        refresh = self.get_token(self.user)

        data["refresh"] = str(refresh)
        data["access"] = str(refresh.access_token)
        data['name'] = self.user.first_name + " " + self.user.last_name
        data['id'] = self.user.id
        data['email'] = self.user.email
        data['role'] = 'Super-Admin' if self.user.role == 1 else 'Rh' if self.user.role == 2 else 'Employee'
        data['picture'] = self.user.picture.url if self.user.picture else None
        if api_settings.UPDATE_LAST_LOGIN:
            update_last_login(None, self.user)

        return data
