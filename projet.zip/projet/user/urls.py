from django.urls import path
from .views import (
    UserRegisterView,
    LogoutAPIView,
    MyTokenObtainPairView,
    ListUsers,
    UserControl,
    UploadUserProfilePicture,
    UpdateUserPassword
)
from rest_framework_simplejwt import views as jwt_views
from django.conf.urls.static import static 
from django.conf import settings





app_name = "user"

urlpatterns = [
  path('register/', UserRegisterView.as_view(), name="register"),
  path('login', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
  path('token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
  path('token/verify/', jwt_views.TokenVerifyView.as_view(), name='token_verify'),
  path('logout', LogoutAPIView.as_view(), name="logout"),
  path('list', ListUsers.as_view(), name="list"),
  path('user/<int:pk>', UserControl.as_view(), name="user"),
  path('upload_picture/<int:pk>', UploadUserProfilePicture.as_view(), name="upload_picture"),
  path('update_password/<int:pk>', UpdateUserPassword.as_view(), name="update_password"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
